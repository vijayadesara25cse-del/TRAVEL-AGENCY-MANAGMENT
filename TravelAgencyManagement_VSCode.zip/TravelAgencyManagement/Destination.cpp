#include "Destination.h"
#include <iomanip>

Destination::Destination() : id(0), city(""), country("") {}
Destination::Destination(int idValue, const std::string& cityValue,
                         const std::string& countryValue)
    : id(idValue), city(cityValue), country(countryValue) {}
Destination::~Destination() {}

int Destination::getId() const { return id; }
std::string Destination::getCity() const { return city; }
std::string Destination::getCountry() const { return country; }

void Destination::display() const {
    std::cout << std::left << std::setw(6) << id
              << std::setw(22) << city << country << '\n';
}
