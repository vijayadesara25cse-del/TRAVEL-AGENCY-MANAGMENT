#include "TravelAgency.h"
#include "FileManager.h"
#include <iostream>
#include <iomanip>
#include <limits>
#include <stdexcept>
#include <sstream>
#include <cstdlib>

using namespace std;

namespace {
int readInt(const string& prompt, int minimum, int maximum) {
    while (true) {
        cout << prompt;
        string line;
        if (!getline(cin, line)) throw runtime_error("Input stream closed.");
        stringstream ss(line);
        int value;
        char extra;
        if ((ss >> value) && !(ss >> extra) && value >= minimum && value <= maximum)
            return value;
        cout << "Invalid input. Enter a number from " << minimum << " to " << maximum << ".\n";
    }
}
string readText(const string& prompt) {
    while (true) {
        cout << prompt;
        string value;
        if (!getline(cin, value)) throw runtime_error("Input stream closed.");
        if (value.find('|') == string::npos && value.find_first_not_of(" \t") != string::npos)
            return value;
        cout << "Input cannot be empty or contain the | character.\n";
    }
}
}

TravelAgency::TravelAgency(const string& directory)
    : customers(new Customer[MAX_CUSTOMERS]), customerCount(0),
      nextCustomerId(1), nextBookingId(1), dataDirectory(directory) {
    packages.emplace_back(1, "Manali", "India", "Mountain Escape", 5, 12500.0);
    packages.emplace_back(2, "Goa", "India", "Beach Holiday", 4, 9800.0);
    packages.emplace_back(3, "Jaipur", "India", "Royal Rajasthan", 3, 7500.0);
    packages.emplace_back(4, "Dubai", "UAE", "City Explorer", 5, 42000.0);
    loadAll();
}
TravelAgency::~TravelAgency() {
    try { saveAll(); } catch (...) {}
    delete[] customers;
}

int TravelAgency::findCustomerIndex(int id) const {
    for (int i = 0; i < customerCount; ++i)
        if (customers[i].getId() == id) return i;
    return -1;
}
const Package* TravelAgency::findPackage(int id) const {
    for (const Package& p : packages) if (p.getId() == id) return &p;
    return nullptr;
}

void TravelAgency::addCustomer() {
    if (customerCount >= MAX_CUSTOMERS) {
        cout << "Customer storage is full.\n"; return;
    }
    string name = readText("Customer name: ");
    string phone = readText("Phone number: ");
    string email = readText("Email address: ");
    if (phone.size() < 7) { cout << "Phone number must contain at least 7 characters.\n"; return; }
    if (email.find('@') == string::npos || email.find('.') == string::npos) {
        cout << "Please enter a valid-looking email address.\n"; return;
    }
    customers[customerCount++] = Customer(nextCustomerId++, name, phone, email);
    cout << "Customer added successfully. Customer ID: " << customers[customerCount-1].getId() << "\n";
}
void TravelAgency::displayCustomers() const {
    if (!customerCount) { cout << "No customers found.\n"; return; }
    cout << left << setw(6) << "ID" << setw(22) << "Name"
         << setw(16) << "Phone" << "Email\n" << string(70, '-') << '\n';
    // Runtime polymorphism: Customer::display is virtual.
    const Customer* view = customers;
    for (int i = 0; i < customerCount; ++i) view[i].display();
}
void TravelAgency::searchCustomer() const {
    int id = readInt("Enter customer ID: ", 1, 1000000);
    int index = findCustomerIndex(id);
    if (index < 0) cout << "Customer not found.\n";
    else {
        cout << left << setw(6) << "ID" << setw(22) << "Name"
             << setw(16) << "Phone" << "Email\n";
        customers[index].display();
    }
}
void TravelAgency::updateCustomer() {
    int id = readInt("Enter customer ID to update: ", 1, 1000000);
    int index = findCustomerIndex(id);
    if (index < 0) { cout << "Customer not found.\n"; return; }
    cout << "Enter replacement details:\n";
    string name = readText("New name: ");
    string phone = readText("New phone: ");
    string email = readText("New email: ");
    if (phone.size() < 7 || email.find('@') == string::npos || email.find('.') == string::npos) {
        cout << "Invalid phone or email. No changes made.\n"; return;
    }
    customers[index].setName(name);
    customers[index].setPhone(phone);
    customers[index].setEmail(email);
    cout << "Customer updated.\n";
}
void TravelAgency::deleteCustomer() {
    int id = readInt("Enter customer ID to delete: ", 1, 1000000);
    int index = findCustomerIndex(id);
    if (index < 0) { cout << "Customer not found.\n"; return; }
    for (const Booking& b : bookings) {
        if (b.getCustomerId() == id && b.getStatus() == "CONFIRMED") {
            cout << "Cannot delete customer with a confirmed booking. Cancel it first.\n"; return;
        }
    }
    for (int i = index; i < customerCount - 1; ++i) customers[i] = customers[i + 1];
    --customerCount;
    cout << "Customer deleted.\n";
}
void TravelAgency::showPackages() const {
    cout << left << setw(6) << "ID" << setw(20) << "Package"
         << setw(18) << "Destination" << setw(8) << "Days" << "Price/person\n"
         << string(70, '-') << '\n';
    for (const Package& p : packages) {
        const Destination* item = &p; // Base pointer demonstrates runtime polymorphism.
        item->display();
    }
}
void TravelAgency::createBooking() {
    if (!customerCount) { cout << "Add a customer before booking.\n"; return; }
    displayCustomers();
    int customerId = readInt("Customer ID: ", 1, 1000000);
    if (findCustomerIndex(customerId) < 0) { cout << "Customer not found.\n"; return; }
    showPackages();
    int packageId = readInt("Package ID: ", 1, 1000000);
    const Package* package = findPackage(packageId);
    if (!package) { cout << "Package not found.\n"; return; }
    int travellers = readInt("Number of travellers (1-20): ", 1, 20);
    double total = package->getPrice() * travellers;
    bookings.emplace_back(nextBookingId++, customerId, packageId, travellers, total);
    cout << "Booking confirmed! Booking ID: " << bookings.back().getId()
         << "\nTotal cost: Rs. " << fixed << setprecision(2) << total << '\n';
}
void TravelAgency::cancelBooking() {
    int id = readInt("Booking ID to cancel: ", 1, 1000000);
    for (Booking& b : bookings) {
        if (b.getId() == id) {
            if (b.getStatus() == "CANCELLED") { cout << "Booking is already cancelled.\n"; return; }
            b.cancel();
            cout << "Booking cancelled. No refund processing is performed by this demo.\n";
            return;
        }
    }
    cout << "Booking not found.\n";
}
void TravelAgency::showBookings() const {
    if (bookings.empty()) { cout << "No bookings found.\n"; return; }
    cout << left << setw(8) << "Book ID" << setw(12) << "Customer"
         << setw(11) << "Package" << setw(12) << "Travellers"
         << setw(15) << "Total (Rs.)" << "Status\n" << string(70, '-') << '\n';
    for (const Booking& b : bookings) b.display();
}
void TravelAgency::showReport() const {
    int confirmed = 0, cancelled = 0;
    double revenue = 0;
    for (const Booking& b : bookings) {
        if (b.getStatus() == "CONFIRMED") { ++confirmed; revenue += b.getTotalCost(); }
        else ++cancelled;
    }
    cout << "\n========== AGENCY REPORT ==========\n"
         << "Registered customers : " << customerCount << '\n'
         << "Available packages   : " << packages.size() << '\n'
         << "Total bookings       : " << bookings.size() << '\n'
         << "Confirmed bookings   : " << confirmed << '\n'
         << "Cancelled bookings   : " << cancelled << '\n'
         << "Confirmed sales total: Rs. " << fixed << setprecision(2) << revenue << '\n'
         << "===================================\n";
}
void TravelAgency::saveAll() const {
    string customerFile = dataDirectory + "/customers.txt";
    string bookingFile = dataDirectory + "/bookings.txt";
    FileManager::saveCustomers(customers, customerCount, customerFile);
    FileManager::saveBookings(bookings, bookingFile);
}
void TravelAgency::loadAll() {
    customerCount = FileManager::loadCustomers(customers, MAX_CUSTOMERS,
                                               dataDirectory + "/customers.txt");
    FileManager::loadBookings(bookings, dataDirectory + "/bookings.txt");
    for (int i = 0; i < customerCount; ++i)
        if (customers[i].getId() >= nextCustomerId) nextCustomerId = customers[i].getId() + 1;
    for (const Booking& b : bookings)
        if (b.getId() >= nextBookingId) nextBookingId = b.getId() + 1;
}
void TravelAgency::run() {
    while (true) {
        cout << "\n====================================\n"
             << "     TRAVEL AGENCY MANAGEMENT\n"
             << "====================================\n"
             << "1. Add Customer\n2. Display Customers\n3. Search Customer\n"
             << "4. Update Customer\n5. Delete Customer\n6. Show Packages\n"
             << "7. Book a Trip\n8. Cancel Booking\n9. Display Bookings\n"
             << "10. Generate Report\n11. Save Data\n12. Load Data\n0. Save and Exit\n";
        try {
            int choice = readInt("Choose an option: ", 0, 12);
            try {
                switch (choice) {
                    case 1: addCustomer(); break;
                    case 2: displayCustomers(); break;
                    case 3: searchCustomer(); break;
                    case 4: updateCustomer(); break;
                    case 5: deleteCustomer(); break;
                    case 6: showPackages(); break;
                    case 7: createBooking(); break;
                    case 8: cancelBooking(); break;
                    case 9: showBookings(); break;
                    case 10: showReport(); break;
                    case 11: saveAll(); cout << "Data saved.\n"; break;
                    case 12: loadAll(); cout << "Data loaded.\n"; break;
                    case 0: saveAll(); cout << "Data saved. Goodbye!\n"; return;
                }
            } catch (const exception& ex) {
                cout << "Operation failed: " << ex.what() << '\n';
            }
        } catch (const exception& ex) {
            cout << "\n" << ex.what() << '\n';
            return;
        }
    }
}
