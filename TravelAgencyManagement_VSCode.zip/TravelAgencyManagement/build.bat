@echo off
g++ -std=c++11 -Wall -Wextra main.cpp Customer.cpp Destination.cpp Package.cpp Booking.cpp FileManager.cpp TravelAgency.cpp -o travel_agency.exe
if errorlevel 1 exit /b 1
echo Build successful. Run travel_agency.exe
