#include "Customer.h"
#include <iomanip>

Customer::Customer() : id(0), name(""), phone(""), email("") {}

Customer::Customer(int idValue, const std::string& nameValue,
                   const std::string& phoneValue, const std::string& emailValue)
    : id(idValue), name(nameValue), phone(phoneValue), email(emailValue) {}

Customer::~Customer() {}

int Customer::getId() const { return id; }
std::string Customer::getName() const { return name; }
std::string Customer::getPhone() const { return phone; }
std::string Customer::getEmail() const { return email; }

void Customer::setName(const std::string& value) { name = value; }
void Customer::setPhone(const std::string& value) { phone = value; }
void Customer::setEmail(const std::string& value) { email = value; }

void Customer::display() const {
    std::cout << std::left << std::setw(6) << id
              << std::setw(22) << name
              << std::setw(16) << phone
              << email << '\n';
}
