#ifndef BOOKING_H
#define BOOKING_H

#include <string>

class Booking {
private:
    int id;
    int customerId;
    int packageId;
    int travellers;
    double totalCost;
    std::string status;

public:
    Booking();
    Booking(int id, int customerId, int packageId, int travellers,
            double totalCost, const std::string& status = "CONFIRMED");

    int getId() const;
    int getCustomerId() const;
    int getPackageId() const;
    int getTravellers() const;
    double getTotalCost() const;
    std::string getStatus() const;
    void cancel();
    void display() const;
};
#endif
