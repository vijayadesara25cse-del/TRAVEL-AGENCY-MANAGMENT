#include "Package.h"
#include <iomanip>

Package::Package() : Destination(), packageName(""), days(0), price(0.0) {}
Package::Package(int idValue, const std::string& cityValue,
                 const std::string& countryValue, const std::string& packageNameValue,
                 int daysValue, double priceValue)
    : Destination(idValue, cityValue, countryValue),
      packageName(packageNameValue), days(daysValue), price(priceValue) {}
Package::~Package() {}

std::string Package::getPackageName() const { return packageName; }
int Package::getDays() const { return days; }
double Package::getPrice() const { return price; }

void Package::display() const {
    std::cout << std::left << std::setw(6) << id
              << std::setw(20) << packageName
              << std::setw(18) << (city + ", " + country)
              << std::setw(8) << days
              << "Rs. " << std::fixed << std::setprecision(2) << price << '\n';
}
