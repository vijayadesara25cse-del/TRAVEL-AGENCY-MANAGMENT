#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>
#include <iostream>

class Customer {
private:
    int id;
    std::string name;
    std::string phone;
    std::string email;

public:
    Customer();
    Customer(int id, const std::string& name, const std::string& phone,
             const std::string& email);
    virtual ~Customer();

    int getId() const;
    std::string getName() const;
    std::string getPhone() const;
    std::string getEmail() const;

    void setName(const std::string& value);
    void setPhone(const std::string& value);
    void setEmail(const std::string& value);
    virtual void display() const;
};
#endif
