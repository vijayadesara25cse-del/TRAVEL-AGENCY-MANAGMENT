#include "Booking.h"
#include <iostream>
#include <iomanip>

Booking::Booking() : id(0), customerId(0), packageId(0), travellers(0),
                     totalCost(0.0), status("CONFIRMED") {}
Booking::Booking(int idValue, int customerIdValue, int packageIdValue,
                 int travellersValue, double costValue, const std::string& statusValue)
    : id(idValue), customerId(customerIdValue), packageId(packageIdValue),
      travellers(travellersValue), totalCost(costValue), status(statusValue) {}

int Booking::getId() const { return id; }
int Booking::getCustomerId() const { return customerId; }
int Booking::getPackageId() const { return packageId; }
int Booking::getTravellers() const { return travellers; }
double Booking::getTotalCost() const { return totalCost; }
std::string Booking::getStatus() const { return status; }
void Booking::cancel() { status = "CANCELLED"; }

void Booking::display() const {
    std::cout << std::left << std::setw(8) << id
              << std::setw(12) << customerId
              << std::setw(11) << packageId
              << std::setw(12) << travellers
              << std::setw(15) << std::fixed << std::setprecision(2) << totalCost
              << status << '\n';
}
