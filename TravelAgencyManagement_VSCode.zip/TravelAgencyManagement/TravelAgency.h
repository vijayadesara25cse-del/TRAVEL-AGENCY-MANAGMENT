#ifndef TRAVELAGENCY_H
#define TRAVELAGENCY_H

#include "Customer.h"
#include "Package.h"
#include "Booking.h"
#include <vector>
#include <string>

class TravelAgency {
private:
    static const int MAX_CUSTOMERS = 200;
    Customer* customers;
    int customerCount;
    std::vector<Package> packages;
    std::vector<Booking> bookings;
    int nextCustomerId;
    int nextBookingId;
    std::string dataDirectory;

    int findCustomerIndex(int id) const;
    const Package* findPackage(int id) const;
    void addCustomer();
    void displayCustomers() const;
    void searchCustomer() const;
    void updateCustomer();
    void deleteCustomer();
    void showPackages() const;
    void createBooking();
    void cancelBooking();
    void showBookings() const;
    void showReport() const;
    void saveAll() const;
    void loadAll();

public:
    explicit TravelAgency(const std::string& directory = "Data");
    ~TravelAgency();
    void run();
};
#endif
