#ifndef PACKAGE_H
#define PACKAGE_H

#include "Destination.h"
#include <string>

class Package : public Destination {
private:
    std::string packageName;
    int days;
    double price;

public:
    Package();
    Package(int id, const std::string& city, const std::string& country,
            const std::string& packageName, int days, double price);
    ~Package() override;

    std::string getPackageName() const;
    int getDays() const;
    double getPrice() const;
    void display() const override;
};
#endif
