#ifndef DESTINATION_H
#define DESTINATION_H

#include <string>
#include <iostream>

class Destination {
protected:
    int id;
    std::string city;
    std::string country;

public:
    Destination();
    Destination(int id, const std::string& city, const std::string& country);
    virtual ~Destination();

    int getId() const;
    std::string getCity() const;
    std::string getCountry() const;
    virtual void display() const;
};
#endif
