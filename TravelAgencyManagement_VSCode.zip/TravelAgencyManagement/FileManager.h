#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <string>
#include <vector>
#include "Customer.h"
#include "Booking.h"

class FileManager {
public:
    static void saveCustomers(const Customer* customers, int count,
                              const std::string& filename);
    static int loadCustomers(Customer* customers, int capacity,
                             const std::string& filename);
    static void saveBookings(const std::vector<Booking>& bookings,
                             const std::string& filename);
    static void loadBookings(std::vector<Booking>& bookings,
                             const std::string& filename);
};
#endif
