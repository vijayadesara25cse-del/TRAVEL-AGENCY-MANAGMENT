#include "TravelAgency.h"
#include <iostream>
#include <exception>

int main() {
    try {
        TravelAgency system("Data");
        system.run();
    } catch (const std::exception& error) {
        std::cerr << "Fatal error: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
