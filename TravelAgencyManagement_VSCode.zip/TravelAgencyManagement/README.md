# Travel Agency Management System

**Project:** IU2541230068 – CPP44  
**Language:** C++  
**Environment:** VS Code + GCC  
**Application:** Console-based OOP project

## Features
- Customer CRUD: add, display, search, update and delete.
- Preloaded travel packages and destinations.
- Booking creation, cancellation and booking list.
- Summary report.
- Text-file persistence for customers and bookings.
- Input validation and exception handling.
- Encapsulation, constructors/destructors, inheritance, virtual functions,
  and dynamically allocated customer storage (`new[]` / `delete[]`).

## Requirements
- GCC compiler (MinGW-w64 on Windows, or GCC on Linux).
- Visual Studio Code.
- C/C++ extension for VS Code is recommended.

## Compile
Open the terminal in this project folder and run:

```bash
g++ -std=c++11 -Wall -Wextra main.cpp Customer.cpp Destination.cpp Package.cpp Booking.cpp FileManager.cpp TravelAgency.cpp -o travel_agency
```

On Windows PowerShell:

```powershell
.\travel_agency.exe
```

On Linux/macOS:

```bash
./travel_agency
```

## Data files
The application reads and writes:
- `Data/customers.txt`
- `Data/bookings.txt`

Run the program from the project root so the relative `Data` directory resolves correctly.
The program attempts to load saved records at startup and saves on exit.

## Menu
0. Save and Exit
1. Add Customer
2. Display Customers
3. Search Customer
4. Update Customer
5. Delete Customer
6. Show Packages
7. Book a Trip
8. Cancel Booking
9. Display Bookings
10. Generate Report
11. Save Data
12. Load Data

## Notes / limitations
- This is an academic demonstration, not a production booking/payment platform.
- Package details are predefined in source code.
- Cancellation marks a booking as cancelled; automatic refunds are not implemented.
- Customer records containing `|` are rejected because this character separates fields in the text file.
