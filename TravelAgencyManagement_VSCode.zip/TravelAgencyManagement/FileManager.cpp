#include "FileManager.h"
#include <fstream>
#include <sstream>

void FileManager::saveCustomers(const Customer* customers, int count,
                                const std::string& filename) {
    std::ofstream out(filename.c_str());
    if (!out) throw std::runtime_error("Could not open customer file for saving.");
    for (int i = 0; i < count; ++i)
        out << customers[i].getId() << '|'
            << customers[i].getName() << '|'
            << customers[i].getPhone() << '|'
            << customers[i].getEmail() << '\n';
}

int FileManager::loadCustomers(Customer* customers, int capacity,
                               const std::string& filename) {
    std::ifstream in(filename.c_str());
    if (!in) return 0;
    int count = 0;
    std::string line;
    while (count < capacity && std::getline(in, line)) {
        std::stringstream ss(line);
        std::string idText, name, phone, email;
        if (!std::getline(ss, idText, '|') || !std::getline(ss, name, '|') ||
            !std::getline(ss, phone, '|') || !std::getline(ss, email)) continue;
        try {
            customers[count++] = Customer(std::stoi(idText), name, phone, email);
        } catch (...) {
            // Ignore malformed records and continue loading.
        }
    }
    return count;
}

void FileManager::saveBookings(const std::vector<Booking>& bookings,
                               const std::string& filename) {
    std::ofstream out(filename.c_str());
    if (!out) throw std::runtime_error("Could not open booking file for saving.");
    for (const Booking& b : bookings)
        out << b.getId() << '|' << b.getCustomerId() << '|'
            << b.getPackageId() << '|' << b.getTravellers() << '|'
            << b.getTotalCost() << '|' << b.getStatus() << '\n';
}

void FileManager::loadBookings(std::vector<Booking>& bookings,
                               const std::string& filename) {
    std::ifstream in(filename.c_str());
    if (!in) return;
    bookings.clear();
    std::string line;
    while (std::getline(in, line)) {
        std::stringstream ss(line);
        std::string id, customer, package, travellers, cost, status;
        if (!std::getline(ss, id, '|') || !std::getline(ss, customer, '|') ||
            !std::getline(ss, package, '|') || !std::getline(ss, travellers, '|') ||
            !std::getline(ss, cost, '|') || !std::getline(ss, status)) continue;
        try {
            bookings.emplace_back(std::stoi(id), std::stoi(customer), std::stoi(package),
                                  std::stoi(travellers), std::stod(cost), status);
        } catch (...) {
            // Ignore malformed records.
        }
    }
}
